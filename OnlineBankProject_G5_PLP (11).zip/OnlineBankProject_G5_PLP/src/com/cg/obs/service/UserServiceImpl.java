package com.cg.obs.service;


import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;


import com.cg.obs.dao.IUserDAO;

import com.cg.obs.exception.UserException;

@Transactional
@Service("userService")
public class UserServiceImpl implements IUserService{

	@Autowired
	private IUserDAO userDao;
	
	
	public UserServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	public UserServiceImpl(IUserDAO userDao) {
		super();
		this.userDao = userDao;
	
	}




	public IUserDAO getUserDao() {
		return userDao;
	}




	public void setUserDao(IUserDAO userDao) {
		this.userDao = userDao;
	}






	@Override
	public void registerUser(Users user) throws UserException
	{
		userDao.registerUser(user);
		
	}
	
	
	@Override
	public Users getUser(int id) throws UserException {
		
		return userDao.getUser(id);
	}

	



	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		System.out.println("In service");
		return userDao.getMiniTransactions(accountno);
	}

	
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno,Date fromDate,Date toDate) throws UserException
	{
		return userDao.getDetailedTransactions(accountno, fromDate, toDate);
		
}

	@Override
	public int getCustomerId(Long accountno) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getCustomerId(accountno);
	}



	@Override
	public Customer getCustomer(int customerid) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getCustomer(customerid);
	
	}
	
	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
	
		userDao.updateCustomerDetails(customer);
	}


	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		return userDao.requestService(services);
	}



	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		// TODO Auto-generated method stub
		return userDao.fundTransfer(transferInfo);
	}



	@Override
	public void changePassword(Users user) throws UserException {

		userDao.changePassword(user);
		
	}



	@Override
	public void updateLockStatus(Users user) throws UserException {
		
		userDao.updateLockStatus(user);
		
	}



	@Override
	public List<Payee> getPayee(long accountid) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getPayee(accountid);
	}



	@Override
	public void insertPayee(Payee payee) throws UserException {
		// TODO Auto-generated method stub
		userDao.insertPayee(payee);
	}



	@Override
	public AccountMaster getAccount(long accountno) {
		// TODO Auto-generated method stub
		return userDao.getAccount(accountno);
	}



	@Override
	public void insertTransaction(Transactions transaction)
			throws UserException {

		userDao.insertTransaction(transaction);
		
	}



	@Override
	public void updateBalance(AccountMaster account) throws UserException {
		
		userDao.updateBalance(account);
	}



	@Override
	public boolean isPayeeAccountExists(long payeeAccountNo)
			throws UserException {
		// TODO Auto-generated method stub
		return userDao.isPayeeAccountExists(payeeAccountNo);
	}


/*
	@Override
	public List<RequestTable> getAllRequest() throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getAllRequest();
	}



	@Override
	public Admin getAdmin() throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getAdmin();
	}



	@Override
	public boolean isCustomerExist(int id) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.isCustomerExist(id);
	}



	@Override
	public int addUsers(Customer customer) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.addUsers(customer);
	}



	@Override
	public int addUsers(AccountMaster accountMaster) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.addUsers(accountMaster);
	}

*/

	@Override
	public RequestTable getAccountId(int custId) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getAccountId(custId);
	}



	@Override
	public int registerUser(Users user, Customer customer) throws UserException {
		// TODO Auto-generated method stub
		return userDao.registerUser(user, customer);
	}



/*	@Override
	public Customer getCustomerbyId(int id) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getCustomerbyId(id);
	}

*/

	@Override
	public int addRequest(RequestTable resTab) throws UserException {
		// TODO Auto-generated method stub
		return userDao.addRequest(resTab);
	}


/*
	@Override
	public List<Transactions> viewMonthlyReport(Date StartDate, Date EndDate)
			throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewMonthlyReport(StartDate, EndDate);
	}



	@Override
	public List<Transactions> viewYearlyReport(Date StartDate, Date EndDate)
			throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewYearlyReport(StartDate, EndDate);
	}



	@Override
	public List<Transactions> viewDailyReport(Date StartDate)
			throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewDailyReport(StartDate);
	}*/



	@Override
	public int isCheckBookRequestExist(Long accountno) throws UserException {
		
		return userDao.isCheckBookRequestExist(accountno);
	}



	@Override
	public ServiceTracker getRequestedServiceList(int requestid)
			throws UserException {
		// TODO Auto-generated method stub
		return userDao.getRequestedServiceList(requestid);
	}
	@Override
	public void updatePayeeBalance(double Updatedbalance, Long accountNo)
			throws UserException {
		
		userDao.updatePayeeBalance(Updatedbalance, accountNo);
		
	}
	


}


